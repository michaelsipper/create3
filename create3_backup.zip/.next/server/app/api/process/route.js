/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/process/route";
exports.ids = ["app/api/process/route"];
exports.modules = {

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "../app-render/work-async-storage.external":
/*!*****************************************************************************!*\
  !*** external "next/dist/server/app-render/work-async-storage.external.js" ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ "./work-unit-async-storage.external":
/*!**********************************************************************************!*\
  !*** external "next/dist/server/app-render/work-unit-async-storage.external.js" ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ "assert":
/*!*************************!*\
  !*** external "assert" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ "child_process":
/*!********************************!*\
  !*** external "child_process" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = require("child_process");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ "dns":
/*!**********************!*\
  !*** external "dns" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("dns");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ "http2":
/*!************************!*\
  !*** external "http2" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("http2");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ "net":
/*!**********************!*\
  !*** external "net" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ "os":
/*!*********************!*\
  !*** external "os" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "process":
/*!**************************!*\
  !*** external "process" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ "punycode":
/*!***************************!*\
  !*** external "punycode" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("punycode");

/***/ }),

/***/ "querystring":
/*!******************************!*\
  !*** external "querystring" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("querystring");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "tls":
/*!**********************!*\
  !*** external "tls" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ "tty":
/*!**********************!*\
  !*** external "tty" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ "worker_threads":
/*!*********************************!*\
  !*** external "worker_threads" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ "puppeteer":
/*!****************************!*\
  !*** external "puppeteer" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = import("puppeteer");;

/***/ }),

/***/ "node:fs":
/*!**************************!*\
  !*** external "node:fs" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ "node:stream":
/*!******************************!*\
  !*** external "node:stream" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:stream");

/***/ }),

/***/ "node:stream/web":
/*!**********************************!*\
  !*** external "node:stream/web" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:stream/web");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fprocess%2Froute&page=%2Fapi%2Fprocess%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fprocess%2Froute.ts&appDir=%2FUsers%2Fmichael%2FDocuments%2FTapdIn%2Fcreate3%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2FUsers%2Fmichael%2FDocuments%2FTapdIn%2Fcreate3&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fprocess%2Froute&page=%2Fapi%2Fprocess%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fprocess%2Froute.ts&appDir=%2FUsers%2Fmichael%2FDocuments%2FTapdIn%2Fcreate3%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2FUsers%2Fmichael%2FDocuments%2FTapdIn%2Fcreate3&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),\n/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"(rsc)/./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _Users_michael_Documents_TapdIn_create3_app_api_process_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/api/process/route.ts */ \"(rsc)/./app/api/process/route.ts\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Users_michael_Documents_TapdIn_create3_app_api_process_route_ts__WEBPACK_IMPORTED_MODULE_3__]);\n_Users_michael_Documents_TapdIn_create3_app_api_process_route_ts__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/process/route\",\n        pathname: \"/api/process\",\n        filename: \"route\",\n        bundlePath: \"app/api/process/route\"\n    },\n    resolvedPagePath: \"/Users/michael/Documents/TapdIn/create3/app/api/process/route.ts\",\n    nextConfigOutput,\n    userland: _Users_michael_Documents_TapdIn_create3_app_api_process_route_ts__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        workAsyncStorage,\n        workUnitAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIvaW5kZXguanM/bmFtZT1hcHAlMkZhcGklMkZwcm9jZXNzJTJGcm91dGUmcGFnZT0lMkZhcGklMkZwcm9jZXNzJTJGcm91dGUmYXBwUGF0aHM9JnBhZ2VQYXRoPXByaXZhdGUtbmV4dC1hcHAtZGlyJTJGYXBpJTJGcHJvY2VzcyUyRnJvdXRlLnRzJmFwcERpcj0lMkZVc2VycyUyRm1pY2hhZWwlMkZEb2N1bWVudHMlMkZUYXBkSW4lMkZjcmVhdGUzJTJGYXBwJnBhZ2VFeHRlbnNpb25zPXRzeCZwYWdlRXh0ZW5zaW9ucz10cyZwYWdlRXh0ZW5zaW9ucz1qc3gmcGFnZUV4dGVuc2lvbnM9anMmcm9vdERpcj0lMkZVc2VycyUyRm1pY2hhZWwlMkZEb2N1bWVudHMlMkZUYXBkSW4lMkZjcmVhdGUzJmlzRGV2PXRydWUmdHNjb25maWdQYXRoPXRzY29uZmlnLmpzb24mYmFzZVBhdGg9JmFzc2V0UHJlZml4PSZuZXh0Q29uZmlnT3V0cHV0PSZwcmVmZXJyZWRSZWdpb249Jm1pZGRsZXdhcmVDb25maWc9ZTMwJTNEISIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUErRjtBQUN2QztBQUNxQjtBQUNnQjtBQUM3RjtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IseUdBQW1CO0FBQzNDO0FBQ0EsY0FBYyxrRUFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsWUFBWTtBQUNaLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxRQUFRLHNEQUFzRDtBQUM5RDtBQUNBLFdBQVcsNEVBQVc7QUFDdEI7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUMwRjs7QUFFMUYscUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jcmVhdGUzLz81ZTI3Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcFJvdXRlUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9yb3V0ZS1tb2R1bGVzL2FwcC1yb3V0ZS9tb2R1bGUuY29tcGlsZWRcIjtcbmltcG9ydCB7IFJvdXRlS2luZCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IHBhdGNoRmV0Y2ggYXMgX3BhdGNoRmV0Y2ggfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9saWIvcGF0Y2gtZmV0Y2hcIjtcbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCIvVXNlcnMvbWljaGFlbC9Eb2N1bWVudHMvVGFwZEluL2NyZWF0ZTMvYXBwL2FwaS9wcm9jZXNzL3JvdXRlLnRzXCI7XG4vLyBXZSBpbmplY3QgdGhlIG5leHRDb25maWdPdXRwdXQgaGVyZSBzbyB0aGF0IHdlIGNhbiB1c2UgdGhlbSBpbiB0aGUgcm91dGVcbi8vIG1vZHVsZS5cbmNvbnN0IG5leHRDb25maWdPdXRwdXQgPSBcIlwiXG5jb25zdCByb3V0ZU1vZHVsZSA9IG5ldyBBcHBSb3V0ZVJvdXRlTW9kdWxlKHtcbiAgICBkZWZpbml0aW9uOiB7XG4gICAgICAgIGtpbmQ6IFJvdXRlS2luZC5BUFBfUk9VVEUsXG4gICAgICAgIHBhZ2U6IFwiL2FwaS9wcm9jZXNzL3JvdXRlXCIsXG4gICAgICAgIHBhdGhuYW1lOiBcIi9hcGkvcHJvY2Vzc1wiLFxuICAgICAgICBmaWxlbmFtZTogXCJyb3V0ZVwiLFxuICAgICAgICBidW5kbGVQYXRoOiBcImFwcC9hcGkvcHJvY2Vzcy9yb3V0ZVwiXG4gICAgfSxcbiAgICByZXNvbHZlZFBhZ2VQYXRoOiBcIi9Vc2Vycy9taWNoYWVsL0RvY3VtZW50cy9UYXBkSW4vY3JlYXRlMy9hcHAvYXBpL3Byb2Nlc3Mvcm91dGUudHNcIixcbiAgICBuZXh0Q29uZmlnT3V0cHV0LFxuICAgIHVzZXJsYW5kXG59KTtcbi8vIFB1bGwgb3V0IHRoZSBleHBvcnRzIHRoYXQgd2UgbmVlZCB0byBleHBvc2UgZnJvbSB0aGUgbW9kdWxlLiBUaGlzIHNob3VsZFxuLy8gYmUgZWxpbWluYXRlZCB3aGVuIHdlJ3ZlIG1vdmVkIHRoZSBvdGhlciByb3V0ZXMgdG8gdGhlIG5ldyBmb3JtYXQuIFRoZXNlXG4vLyBhcmUgdXNlZCB0byBob29rIGludG8gdGhlIHJvdXRlLlxuY29uc3QgeyB3b3JrQXN5bmNTdG9yYWdlLCB3b3JrVW5pdEFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MgfSA9IHJvdXRlTW9kdWxlO1xuZnVuY3Rpb24gcGF0Y2hGZXRjaCgpIHtcbiAgICByZXR1cm4gX3BhdGNoRmV0Y2goe1xuICAgICAgICB3b3JrQXN5bmNTdG9yYWdlLFxuICAgICAgICB3b3JrVW5pdEFzeW5jU3RvcmFnZVxuICAgIH0pO1xufVxuZXhwb3J0IHsgcm91dGVNb2R1bGUsIHdvcmtBc3luY1N0b3JhZ2UsIHdvcmtVbml0QXN5bmNTdG9yYWdlLCBzZXJ2ZXJIb29rcywgcGF0Y2hGZXRjaCwgIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFwcC1yb3V0ZS5qcy5tYXAiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fprocess%2Froute&page=%2Fapi%2Fprocess%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fprocess%2Froute.ts&appDir=%2FUsers%2Fmichael%2FDocuments%2FTapdIn%2Fcreate3%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2FUsers%2Fmichael%2FDocuments%2FTapdIn%2Fcreate3&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(rsc)/./app/api/process/route.ts":
/*!**********************************!*\
  !*** ./app/api/process/route.ts ***!
  \**********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   POST: () => (/* binding */ POST)\n/* harmony export */ });\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n/* harmony import */ var _google_cloud_vision__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @google-cloud/vision */ \"(rsc)/./node_modules/@google-cloud/vision/build/src/index.js\");\n/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! openai */ \"(rsc)/./node_modules/openai/index.mjs\");\n/* harmony import */ var puppeteer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! puppeteer */ \"puppeteer\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([puppeteer__WEBPACK_IMPORTED_MODULE_2__]);\npuppeteer__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n// Check for required environment variables\nif (!process.env.GOOGLE_CLOUD_PROJECT_ID) {\n    throw new Error('GOOGLE_CLOUD_PROJECT_ID is not defined');\n}\nif (!process.env.GOOGLE_CLOUD_PRIVATE_KEY) {\n    throw new Error('GOOGLE_CLOUD_PRIVATE_KEY is not defined');\n}\nif (!process.env.GOOGLE_CLOUD_CLIENT_EMAIL) {\n    throw new Error('GOOGLE_CLOUD_CLIENT_EMAIL is not defined');\n}\nif (!process.env.OPENAI_API_KEY) {\n    throw new Error('OPENAI_API_KEY is not defined');\n}\n// Initialize Google Vision Client using environment variables\nconst client = new _google_cloud_vision__WEBPACK_IMPORTED_MODULE_1__[\"default\"].ImageAnnotatorClient({\n    credentials: {\n        project_id: process.env.GOOGLE_CLOUD_PROJECT_ID,\n        private_key: process.env.GOOGLE_CLOUD_PRIVATE_KEY.replace(/\\\\n/g, '\\n'),\n        client_email: process.env.GOOGLE_CLOUD_CLIENT_EMAIL\n    }\n});\n// Initialize OpenAI with environment variable\nconst openai = new openai__WEBPACK_IMPORTED_MODULE_3__[\"default\"]({\n    apiKey: process.env.OPENAI_API_KEY\n});\n// Helper function to parse dates and times into ISO format\nfunction parseDateTimeString(dateTimeString) {\n    try {\n        const currentYear = new Date().getFullYear();\n        // Handle short date formats like \"10/25\" or \"10/25/19\"\n        const shortDateRegex = /(\\d{1,2})\\/(\\d{1,2})(?:\\/(\\d{2,4}))?/;\n        const match = dateTimeString.match(shortDateRegex);\n        if (match) {\n            const [_, month, day, yearPart] = match;\n            let year = yearPart ? parseInt(yearPart) : currentYear;\n            // Convert 2-digit year to full year\n            if (year < 100) {\n                // If the 2-digit year would result in a past date, assume it's for the next occurrence\n                year = year + 2000;\n                const proposedDate = new Date(year, parseInt(month) - 1, parseInt(day));\n                if (proposedDate < new Date()) {\n                    year = currentYear;\n                }\n            }\n            // For any date that's already passed this year, assume next year\n            const proposedDate = new Date(year, parseInt(month) - 1, parseInt(day));\n            if (proposedDate < new Date()) {\n                year = currentYear + 1;\n            }\n            // Default time based on event type (will be overridden if time is specified)\n            let defaultHour = 19; // 7 PM default\n            let defaultMinute = 0;\n            // Look for time in the original string\n            const timeMatch = dateTimeString.match(/(\\d{1,2}):(\\d{2})\\s*(am|pm)?/i);\n            if (timeMatch) {\n                const [_, hours, minutes, meridiem] = timeMatch;\n                let hour = parseInt(hours);\n                if (meridiem?.toLowerCase() === 'pm' && hour < 12) hour += 12;\n                if (meridiem?.toLowerCase() === 'am' && hour === 12) hour = 0;\n                defaultHour = hour;\n                defaultMinute = parseInt(minutes);\n            }\n            const finalDate = new Date(year, parseInt(month) - 1, parseInt(day), defaultHour, defaultMinute);\n            return finalDate.toISOString();\n        }\n        // If no match, try direct parsing\n        const date = new Date(dateTimeString);\n        if (!isNaN(date.getTime())) {\n            // If the parsed date is in the past, adjust to next year\n            if (date < new Date()) {\n                date.setFullYear(currentYear + 1);\n            }\n            return date.toISOString();\n        }\n        return null;\n    } catch (error) {\n        console.error('Date parsing error:', error);\n        return null;\n    }\n}\nasync function POST(req) {\n    console.log('API endpoint hit');\n    try {\n        const formData = await req.formData();\n        const url = formData.get('url');\n        const file = formData.get('image');\n        const currentYear = new Date().getFullYear();\n        const systemPrompt = `You are a helpful assistant that extracts event details from text descriptions. \n    Pay special attention to dates and times:\n    - Always look for both date AND time information\n    - Today's date is ${new Date().toLocaleDateString()} and the current year is ${currentYear}\n    - If a year isn't specified, ask yourself what year is it at this moment, and use the current year.\n    - If the event includes dates that have already passed, use the next nearest date from today's.\n    - For dates without times specified, use contextual clues about the event type:\n      * Evening events (parties, shows): default to 7:00 PM\n      * Morning events (brunches, races): default to 9:00 AM\n      * Business events: default to 10:00 AM\n    - Look for time zone information, defaulting to local time if none is specified\n    - Handle relative dates like \"tomorrow\", \"next Friday\", etc.\n    - Recognize various time formats (12-hour, 24-hour, written out)\n    \n    Return a JSON object with these fields:\n    - title: string (the event name)\n    - dates: string[] (array of all mentioned dates with times, in formats like \"March 15, ${currentYear} 7:30 PM\" or \"${currentYear}-03-15 19:30\")\n    - location: { name: string, address?: string }\n    - description: string\n    - type: \"social\" | \"business\" | \"entertainment\"\n    `;\n        let extractedText = '';\n        // Handle URL processing with Puppeteer\n        if (url) {\n            console.log('Processing URL:', url);\n            const browser = await puppeteer__WEBPACK_IMPORTED_MODULE_2__[\"default\"].launch();\n            const page = await browser.newPage();\n            await page.goto(url, {\n                waitUntil: 'networkidle2'\n            });\n            extractedText = await page.evaluate(()=>document.body.innerText);\n            await browser.close();\n        }\n        // Handle Image processing with Google Vision\n        if (file) {\n            console.log('Processing file:', file.name);\n            const buffer = Buffer.from(await file.arrayBuffer());\n            const [result] = await client.textDetection(buffer);\n            const detections = result.textAnnotations;\n            extractedText = detections ? detections[0].description : '';\n        }\n        if (!extractedText) {\n            return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n                error: 'No text could be extracted'\n            }, {\n                status: 400\n            });\n        }\n        console.log('Extracted text:', extractedText);\n        const response = await openai.chat.completions.create({\n            model: \"gpt-3.5-turbo\",\n            messages: [\n                {\n                    role: \"system\",\n                    content: systemPrompt\n                },\n                {\n                    role: \"user\",\n                    content: `Extract event information from this text:\\n\\n${extractedText}`\n                }\n            ],\n            max_tokens: 500\n        });\n        const gptContent = response.choices[0]?.message?.content;\n        const rawEventData = JSON.parse(gptContent || '{}');\n        // Process and format the dates\n        const processedEventData = {\n            ...rawEventData,\n            datetime: rawEventData.dates && rawEventData.dates.length > 0 ? parseDateTimeString(rawEventData.dates[0]) : null,\n            // Keep the original dates array for reference\n            allDates: rawEventData.dates?.map((date)=>({\n                    original: date,\n                    parsed: parseDateTimeString(date)\n                }))\n        };\n        console.log('Processed event data:', processedEventData);\n        if (!processedEventData.datetime) {\n            console.warn('Could not parse any valid dates from:', rawEventData.dates);\n        }\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json(processedEventData);\n    } catch (error) {\n        console.error('Processing error:', error);\n        return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json({\n            error: 'Failed to process request'\n        }, {\n            status: 500\n        });\n    }\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvYXBpL3Byb2Nlc3Mvcm91dGUudHMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBMkM7QUFDRDtBQUNkO0FBQ007QUFFbEMsMkNBQTJDO0FBQzNDLElBQUksQ0FBQ0ksUUFBUUMsR0FBRyxDQUFDQyx1QkFBdUIsRUFBRTtJQUN4QyxNQUFNLElBQUlDLE1BQU07QUFDbEI7QUFDQSxJQUFJLENBQUNILFFBQVFDLEdBQUcsQ0FBQ0csd0JBQXdCLEVBQUU7SUFDekMsTUFBTSxJQUFJRCxNQUFNO0FBQ2xCO0FBQ0EsSUFBSSxDQUFDSCxRQUFRQyxHQUFHLENBQUNJLHlCQUF5QixFQUFFO0lBQzFDLE1BQU0sSUFBSUYsTUFBTTtBQUNsQjtBQUNBLElBQUksQ0FBQ0gsUUFBUUMsR0FBRyxDQUFDSyxjQUFjLEVBQUU7SUFDL0IsTUFBTSxJQUFJSCxNQUFNO0FBQ2xCO0FBRUEsOERBQThEO0FBQzlELE1BQU1JLFNBQVMsSUFBSVYsaUZBQTJCLENBQUM7SUFDN0NZLGFBQWE7UUFDWEMsWUFBWVYsUUFBUUMsR0FBRyxDQUFDQyx1QkFBdUI7UUFDL0NTLGFBQWEsUUFBU1YsR0FBRyxDQUFDRyx3QkFBd0IsQ0FBWVEsT0FBTyxDQUFDLFFBQVE7UUFDOUVDLGNBQWNiLFFBQVFDLEdBQUcsQ0FBQ0kseUJBQXlCO0lBQ3JEO0FBQ0Y7QUFFQSw4Q0FBOEM7QUFDOUMsTUFBTVMsU0FBUyxJQUFJaEIsOENBQU1BLENBQUM7SUFDeEJpQixRQUFRZixRQUFRQyxHQUFHLENBQUNLLGNBQWM7QUFDcEM7QUFFQSwyREFBMkQ7QUFDM0QsU0FBU1Usb0JBQW9CQyxjQUFzQjtJQUNqRCxJQUFJO1FBQ0YsTUFBTUMsY0FBYyxJQUFJQyxPQUFPQyxXQUFXO1FBRTFDLHVEQUF1RDtRQUN2RCxNQUFNQyxpQkFBaUI7UUFDdkIsTUFBTUMsUUFBUUwsZUFBZUssS0FBSyxDQUFDRDtRQUVuQyxJQUFJQyxPQUFPO1lBQ1QsTUFBTSxDQUFDQyxHQUFHQyxPQUFPQyxLQUFLQyxTQUFTLEdBQUdKO1lBQ2xDLElBQUlLLE9BQU9ELFdBQVdFLFNBQVNGLFlBQVlSO1lBRTNDLG9DQUFvQztZQUNwQyxJQUFJUyxPQUFPLEtBQUs7Z0JBQ2QsdUZBQXVGO2dCQUN2RkEsT0FBT0EsT0FBTztnQkFDZCxNQUFNRSxlQUFlLElBQUlWLEtBQUtRLE1BQU1DLFNBQVNKLFNBQVMsR0FBR0ksU0FBU0g7Z0JBQ2xFLElBQUlJLGVBQWUsSUFBSVYsUUFBUTtvQkFDN0JRLE9BQU9UO2dCQUNUO1lBQ0Y7WUFFQSxpRUFBaUU7WUFDakUsTUFBTVcsZUFBZSxJQUFJVixLQUFLUSxNQUFNQyxTQUFTSixTQUFTLEdBQUdJLFNBQVNIO1lBQ2xFLElBQUlJLGVBQWUsSUFBSVYsUUFBUTtnQkFDN0JRLE9BQU9ULGNBQWM7WUFDdkI7WUFFQSw2RUFBNkU7WUFDN0UsSUFBSVksY0FBYyxJQUFJLGVBQWU7WUFDckMsSUFBSUMsZ0JBQWdCO1lBRXBCLHVDQUF1QztZQUN2QyxNQUFNQyxZQUFZZixlQUFlSyxLQUFLLENBQUM7WUFDdkMsSUFBSVUsV0FBVztnQkFDYixNQUFNLENBQUNULEdBQUdVLE9BQU9DLFNBQVNDLFNBQVMsR0FBR0g7Z0JBQ3RDLElBQUlJLE9BQU9SLFNBQVNLO2dCQUNwQixJQUFJRSxVQUFVRSxrQkFBa0IsUUFBUUQsT0FBTyxJQUFJQSxRQUFRO2dCQUMzRCxJQUFJRCxVQUFVRSxrQkFBa0IsUUFBUUQsU0FBUyxJQUFJQSxPQUFPO2dCQUM1RE4sY0FBY007Z0JBQ2RMLGdCQUFnQkgsU0FBU007WUFDM0I7WUFFQSxNQUFNSSxZQUFZLElBQUluQixLQUFLUSxNQUFNQyxTQUFTSixTQUFTLEdBQUdJLFNBQVNILE1BQU1LLGFBQWFDO1lBQ2xGLE9BQU9PLFVBQVVDLFdBQVc7UUFDOUI7UUFFQSxrQ0FBa0M7UUFDbEMsTUFBTUMsT0FBTyxJQUFJckIsS0FBS0Y7UUFDdEIsSUFBSSxDQUFDd0IsTUFBTUQsS0FBS0UsT0FBTyxLQUFLO1lBQzFCLHlEQUF5RDtZQUN6RCxJQUFJRixPQUFPLElBQUlyQixRQUFRO2dCQUNyQnFCLEtBQUtHLFdBQVcsQ0FBQ3pCLGNBQWM7WUFDakM7WUFDQSxPQUFPc0IsS0FBS0QsV0FBVztRQUN6QjtRQUVBLE9BQU87SUFDVCxFQUFFLE9BQU9LLE9BQU87UUFDZEMsUUFBUUQsS0FBSyxDQUFDLHVCQUF1QkE7UUFDckMsT0FBTztJQUNUO0FBQ0Y7QUFFTyxlQUFlRSxLQUFLQyxHQUFZO0lBQ3JDRixRQUFRRyxHQUFHLENBQUM7SUFFWixJQUFJO1FBQ0YsTUFBTUMsV0FBVyxNQUFNRixJQUFJRSxRQUFRO1FBQ25DLE1BQU1DLE1BQU1ELFNBQVNFLEdBQUcsQ0FBQztRQUN6QixNQUFNQyxPQUFPSCxTQUFTRSxHQUFHLENBQUM7UUFFMUIsTUFBTWpDLGNBQWMsSUFBSUMsT0FBT0MsV0FBVztRQUUxQyxNQUFNaUMsZUFBZSxDQUFDOzs7c0JBR0osRUFBRSxJQUFJbEMsT0FBT21DLGtCQUFrQixHQUFHLHlCQUF5QixFQUFFcEMsWUFBWTs7Ozs7Ozs7Ozs7OzsyRkFhSixFQUFFQSxZQUFZLGNBQWMsRUFBRUEsWUFBWTs7OztJQUlqSSxDQUFDO1FBRUQsSUFBSXFDLGdCQUFnQjtRQUVwQix1Q0FBdUM7UUFDdkMsSUFBSUwsS0FBSztZQUNQTCxRQUFRRyxHQUFHLENBQUMsbUJBQW1CRTtZQUMvQixNQUFNTSxVQUFVLE1BQU16RCx3REFBZ0I7WUFDdEMsTUFBTTJELE9BQU8sTUFBTUYsUUFBUUcsT0FBTztZQUNsQyxNQUFNRCxLQUFLRSxJQUFJLENBQUNWLEtBQUs7Z0JBQUVXLFdBQVc7WUFBZTtZQUNqRE4sZ0JBQWdCLE1BQU1HLEtBQUtJLFFBQVEsQ0FBQyxJQUFNQyxTQUFTQyxJQUFJLENBQUNDLFNBQVM7WUFDakUsTUFBTVQsUUFBUVUsS0FBSztRQUNyQjtRQUVBLDZDQUE2QztRQUM3QyxJQUFJZCxNQUFNO1lBQ1JQLFFBQVFHLEdBQUcsQ0FBQyxvQkFBb0JJLEtBQUtlLElBQUk7WUFDekMsTUFBTUMsU0FBU0MsT0FBT0MsSUFBSSxDQUFDLE1BQU1sQixLQUFLbUIsV0FBVztZQUNqRCxNQUFNLENBQUNDLE9BQU8sR0FBRyxNQUFNakUsT0FBT2tFLGFBQWEsQ0FBQ0w7WUFDNUMsTUFBTU0sYUFBYUYsT0FBT0csZUFBZTtZQUN6Q3BCLGdCQUFnQm1CLGFBQWFBLFVBQVUsQ0FBQyxFQUFFLENBQUNFLFdBQVcsR0FBRztRQUMzRDtRQUVBLElBQUksQ0FBQ3JCLGVBQWU7WUFDbEIsT0FBTzNELHFEQUFZQSxDQUFDaUYsSUFBSSxDQUFDO2dCQUFFakMsT0FBTztZQUE2QixHQUFHO2dCQUFFa0MsUUFBUTtZQUFJO1FBQ2xGO1FBRUFqQyxRQUFRRyxHQUFHLENBQUMsbUJBQW1CTztRQUUvQixNQUFNd0IsV0FBVyxNQUFNakUsT0FBT2tFLElBQUksQ0FBQ0MsV0FBVyxDQUFDQyxNQUFNLENBQUM7WUFDcERDLE9BQU87WUFDUEMsVUFBVTtnQkFDUjtvQkFDRUMsTUFBTTtvQkFDTkMsU0FBU2pDO2dCQUNYO2dCQUNBO29CQUNFZ0MsTUFBTTtvQkFDTkMsU0FBUyxDQUFDLDZDQUE2QyxFQUFFL0IsZUFBZTtnQkFDMUU7YUFDRDtZQUNEZ0MsWUFBWTtRQUNkO1FBRUEsTUFBTUMsYUFBYVQsU0FBU1UsT0FBTyxDQUFDLEVBQUUsRUFBRUMsU0FBU0o7UUFDakQsTUFBTUssZUFBZUMsS0FBS0MsS0FBSyxDQUFDTCxjQUFjO1FBRTlDLCtCQUErQjtRQUMvQixNQUFNTSxxQkFBcUI7WUFDekIsR0FBR0gsWUFBWTtZQUNmSSxVQUFVSixhQUFhSyxLQUFLLElBQUlMLGFBQWFLLEtBQUssQ0FBQ0MsTUFBTSxHQUFHLElBQ3hEakYsb0JBQW9CMkUsYUFBYUssS0FBSyxDQUFDLEVBQUUsSUFDekM7WUFDSiw4Q0FBOEM7WUFDOUNFLFVBQVVQLGFBQWFLLEtBQUssRUFBRUcsSUFBSSxDQUFDM0QsT0FBa0I7b0JBQ25ENEQsVUFBVTVEO29CQUNWNkQsUUFBUXJGLG9CQUFvQndCO2dCQUM5QjtRQUNGO1FBRUFLLFFBQVFHLEdBQUcsQ0FBQyx5QkFBeUI4QztRQUVyQyxJQUFJLENBQUNBLG1CQUFtQkMsUUFBUSxFQUFFO1lBQ2hDbEQsUUFBUXlELElBQUksQ0FBQyx5Q0FBeUNYLGFBQWFLLEtBQUs7UUFDMUU7UUFFQSxPQUFPcEcscURBQVlBLENBQUNpRixJQUFJLENBQUNpQjtJQUUzQixFQUFFLE9BQU9sRCxPQUFPO1FBQ2RDLFFBQVFELEtBQUssQ0FBQyxxQkFBcUJBO1FBQ25DLE9BQU9oRCxxREFBWUEsQ0FBQ2lGLElBQUksQ0FBQztZQUFFakMsT0FBTztRQUE0QixHQUFHO1lBQUVrQyxRQUFRO1FBQUk7SUFDakY7QUFDRiIsInNvdXJjZXMiOlsid2VicGFjazovL2NyZWF0ZTMvLi9hcHAvYXBpL3Byb2Nlc3Mvcm91dGUudHM/MmUyYiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZXh0UmVzcG9uc2UgfSBmcm9tICduZXh0L3NlcnZlcic7XG5pbXBvcnQgdmlzaW9uIGZyb20gJ0Bnb29nbGUtY2xvdWQvdmlzaW9uJztcbmltcG9ydCBPcGVuQUkgZnJvbSAnb3BlbmFpJztcbmltcG9ydCBwdXBwZXRlZXIgZnJvbSAncHVwcGV0ZWVyJztcblxuLy8gQ2hlY2sgZm9yIHJlcXVpcmVkIGVudmlyb25tZW50IHZhcmlhYmxlc1xuaWYgKCFwcm9jZXNzLmVudi5HT09HTEVfQ0xPVURfUFJPSkVDVF9JRCkge1xuICB0aHJvdyBuZXcgRXJyb3IoJ0dPT0dMRV9DTE9VRF9QUk9KRUNUX0lEIGlzIG5vdCBkZWZpbmVkJyk7XG59XG5pZiAoIXByb2Nlc3MuZW52LkdPT0dMRV9DTE9VRF9QUklWQVRFX0tFWSkge1xuICB0aHJvdyBuZXcgRXJyb3IoJ0dPT0dMRV9DTE9VRF9QUklWQVRFX0tFWSBpcyBub3QgZGVmaW5lZCcpO1xufVxuaWYgKCFwcm9jZXNzLmVudi5HT09HTEVfQ0xPVURfQ0xJRU5UX0VNQUlMKSB7XG4gIHRocm93IG5ldyBFcnJvcignR09PR0xFX0NMT1VEX0NMSUVOVF9FTUFJTCBpcyBub3QgZGVmaW5lZCcpO1xufVxuaWYgKCFwcm9jZXNzLmVudi5PUEVOQUlfQVBJX0tFWSkge1xuICB0aHJvdyBuZXcgRXJyb3IoJ09QRU5BSV9BUElfS0VZIGlzIG5vdCBkZWZpbmVkJyk7XG59XG5cbi8vIEluaXRpYWxpemUgR29vZ2xlIFZpc2lvbiBDbGllbnQgdXNpbmcgZW52aXJvbm1lbnQgdmFyaWFibGVzXG5jb25zdCBjbGllbnQgPSBuZXcgdmlzaW9uLkltYWdlQW5ub3RhdG9yQ2xpZW50KHtcbiAgY3JlZGVudGlhbHM6IHtcbiAgICBwcm9qZWN0X2lkOiBwcm9jZXNzLmVudi5HT09HTEVfQ0xPVURfUFJPSkVDVF9JRCBhcyBzdHJpbmcsXG4gICAgcHJpdmF0ZV9rZXk6IChwcm9jZXNzLmVudi5HT09HTEVfQ0xPVURfUFJJVkFURV9LRVkgYXMgc3RyaW5nKS5yZXBsYWNlKC9cXFxcbi9nLCAnXFxuJyksXG4gICAgY2xpZW50X2VtYWlsOiBwcm9jZXNzLmVudi5HT09HTEVfQ0xPVURfQ0xJRU5UX0VNQUlMIGFzIHN0cmluZyxcbiAgfSxcbn0pO1xuXG4vLyBJbml0aWFsaXplIE9wZW5BSSB3aXRoIGVudmlyb25tZW50IHZhcmlhYmxlXG5jb25zdCBvcGVuYWkgPSBuZXcgT3BlbkFJKHtcbiAgYXBpS2V5OiBwcm9jZXNzLmVudi5PUEVOQUlfQVBJX0tFWSxcbn0pO1xuXG4vLyBIZWxwZXIgZnVuY3Rpb24gdG8gcGFyc2UgZGF0ZXMgYW5kIHRpbWVzIGludG8gSVNPIGZvcm1hdFxuZnVuY3Rpb24gcGFyc2VEYXRlVGltZVN0cmluZyhkYXRlVGltZVN0cmluZzogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gIHRyeSB7XG4gICAgY29uc3QgY3VycmVudFllYXIgPSBuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCk7XG4gICAgXG4gICAgLy8gSGFuZGxlIHNob3J0IGRhdGUgZm9ybWF0cyBsaWtlIFwiMTAvMjVcIiBvciBcIjEwLzI1LzE5XCJcbiAgICBjb25zdCBzaG9ydERhdGVSZWdleCA9IC8oXFxkezEsMn0pXFwvKFxcZHsxLDJ9KSg/OlxcLyhcXGR7Miw0fSkpPy87XG4gICAgY29uc3QgbWF0Y2ggPSBkYXRlVGltZVN0cmluZy5tYXRjaChzaG9ydERhdGVSZWdleCk7XG4gICAgXG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICBjb25zdCBbXywgbW9udGgsIGRheSwgeWVhclBhcnRdID0gbWF0Y2g7XG4gICAgICBsZXQgeWVhciA9IHllYXJQYXJ0ID8gcGFyc2VJbnQoeWVhclBhcnQpIDogY3VycmVudFllYXI7XG4gICAgICBcbiAgICAgIC8vIENvbnZlcnQgMi1kaWdpdCB5ZWFyIHRvIGZ1bGwgeWVhclxuICAgICAgaWYgKHllYXIgPCAxMDApIHtcbiAgICAgICAgLy8gSWYgdGhlIDItZGlnaXQgeWVhciB3b3VsZCByZXN1bHQgaW4gYSBwYXN0IGRhdGUsIGFzc3VtZSBpdCdzIGZvciB0aGUgbmV4dCBvY2N1cnJlbmNlXG4gICAgICAgIHllYXIgPSB5ZWFyICsgMjAwMDtcbiAgICAgICAgY29uc3QgcHJvcG9zZWREYXRlID0gbmV3IERhdGUoeWVhciwgcGFyc2VJbnQobW9udGgpIC0gMSwgcGFyc2VJbnQoZGF5KSk7XG4gICAgICAgIGlmIChwcm9wb3NlZERhdGUgPCBuZXcgRGF0ZSgpKSB7XG4gICAgICAgICAgeWVhciA9IGN1cnJlbnRZZWFyO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBcbiAgICAgIC8vIEZvciBhbnkgZGF0ZSB0aGF0J3MgYWxyZWFkeSBwYXNzZWQgdGhpcyB5ZWFyLCBhc3N1bWUgbmV4dCB5ZWFyXG4gICAgICBjb25zdCBwcm9wb3NlZERhdGUgPSBuZXcgRGF0ZSh5ZWFyLCBwYXJzZUludChtb250aCkgLSAxLCBwYXJzZUludChkYXkpKTtcbiAgICAgIGlmIChwcm9wb3NlZERhdGUgPCBuZXcgRGF0ZSgpKSB7XG4gICAgICAgIHllYXIgPSBjdXJyZW50WWVhciArIDE7XG4gICAgICB9XG4gICAgICBcbiAgICAgIC8vIERlZmF1bHQgdGltZSBiYXNlZCBvbiBldmVudCB0eXBlICh3aWxsIGJlIG92ZXJyaWRkZW4gaWYgdGltZSBpcyBzcGVjaWZpZWQpXG4gICAgICBsZXQgZGVmYXVsdEhvdXIgPSAxOTsgLy8gNyBQTSBkZWZhdWx0XG4gICAgICBsZXQgZGVmYXVsdE1pbnV0ZSA9IDA7XG4gICAgICBcbiAgICAgIC8vIExvb2sgZm9yIHRpbWUgaW4gdGhlIG9yaWdpbmFsIHN0cmluZ1xuICAgICAgY29uc3QgdGltZU1hdGNoID0gZGF0ZVRpbWVTdHJpbmcubWF0Y2goLyhcXGR7MSwyfSk6KFxcZHsyfSlcXHMqKGFtfHBtKT8vaSk7XG4gICAgICBpZiAodGltZU1hdGNoKSB7XG4gICAgICAgIGNvbnN0IFtfLCBob3VycywgbWludXRlcywgbWVyaWRpZW1dID0gdGltZU1hdGNoO1xuICAgICAgICBsZXQgaG91ciA9IHBhcnNlSW50KGhvdXJzKTtcbiAgICAgICAgaWYgKG1lcmlkaWVtPy50b0xvd2VyQ2FzZSgpID09PSAncG0nICYmIGhvdXIgPCAxMikgaG91ciArPSAxMjtcbiAgICAgICAgaWYgKG1lcmlkaWVtPy50b0xvd2VyQ2FzZSgpID09PSAnYW0nICYmIGhvdXIgPT09IDEyKSBob3VyID0gMDtcbiAgICAgICAgZGVmYXVsdEhvdXIgPSBob3VyO1xuICAgICAgICBkZWZhdWx0TWludXRlID0gcGFyc2VJbnQobWludXRlcyk7XG4gICAgICB9XG4gICAgICBcbiAgICAgIGNvbnN0IGZpbmFsRGF0ZSA9IG5ldyBEYXRlKHllYXIsIHBhcnNlSW50KG1vbnRoKSAtIDEsIHBhcnNlSW50KGRheSksIGRlZmF1bHRIb3VyLCBkZWZhdWx0TWludXRlKTtcbiAgICAgIHJldHVybiBmaW5hbERhdGUudG9JU09TdHJpbmcoKTtcbiAgICB9XG4gICAgXG4gICAgLy8gSWYgbm8gbWF0Y2gsIHRyeSBkaXJlY3QgcGFyc2luZ1xuICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShkYXRlVGltZVN0cmluZyk7XG4gICAgaWYgKCFpc05hTihkYXRlLmdldFRpbWUoKSkpIHtcbiAgICAgIC8vIElmIHRoZSBwYXJzZWQgZGF0ZSBpcyBpbiB0aGUgcGFzdCwgYWRqdXN0IHRvIG5leHQgeWVhclxuICAgICAgaWYgKGRhdGUgPCBuZXcgRGF0ZSgpKSB7XG4gICAgICAgIGRhdGUuc2V0RnVsbFllYXIoY3VycmVudFllYXIgKyAxKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBkYXRlLnRvSVNPU3RyaW5nKCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG51bGw7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcignRGF0ZSBwYXJzaW5nIGVycm9yOicsIGVycm9yKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gUE9TVChyZXE6IFJlcXVlc3QpIHtcbiAgY29uc29sZS5sb2coJ0FQSSBlbmRwb2ludCBoaXQnKTtcblxuICB0cnkge1xuICAgIGNvbnN0IGZvcm1EYXRhID0gYXdhaXQgcmVxLmZvcm1EYXRhKCk7XG4gICAgY29uc3QgdXJsID0gZm9ybURhdGEuZ2V0KCd1cmwnKSBhcyBzdHJpbmcgfCBudWxsO1xuICAgIGNvbnN0IGZpbGUgPSBmb3JtRGF0YS5nZXQoJ2ltYWdlJykgYXMgRmlsZSB8IG51bGw7XG5cbiAgICBjb25zdCBjdXJyZW50WWVhciA9IG5ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKTtcbiAgICBcbiAgICBjb25zdCBzeXN0ZW1Qcm9tcHQgPSBgWW91IGFyZSBhIGhlbHBmdWwgYXNzaXN0YW50IHRoYXQgZXh0cmFjdHMgZXZlbnQgZGV0YWlscyBmcm9tIHRleHQgZGVzY3JpcHRpb25zLiBcbiAgICBQYXkgc3BlY2lhbCBhdHRlbnRpb24gdG8gZGF0ZXMgYW5kIHRpbWVzOlxuICAgIC0gQWx3YXlzIGxvb2sgZm9yIGJvdGggZGF0ZSBBTkQgdGltZSBpbmZvcm1hdGlvblxuICAgIC0gVG9kYXkncyBkYXRlIGlzICR7bmV3IERhdGUoKS50b0xvY2FsZURhdGVTdHJpbmcoKX0gYW5kIHRoZSBjdXJyZW50IHllYXIgaXMgJHtjdXJyZW50WWVhcn1cbiAgICAtIElmIGEgeWVhciBpc24ndCBzcGVjaWZpZWQsIGFzayB5b3Vyc2VsZiB3aGF0IHllYXIgaXMgaXQgYXQgdGhpcyBtb21lbnQsIGFuZCB1c2UgdGhlIGN1cnJlbnQgeWVhci5cbiAgICAtIElmIHRoZSBldmVudCBpbmNsdWRlcyBkYXRlcyB0aGF0IGhhdmUgYWxyZWFkeSBwYXNzZWQsIHVzZSB0aGUgbmV4dCBuZWFyZXN0IGRhdGUgZnJvbSB0b2RheSdzLlxuICAgIC0gRm9yIGRhdGVzIHdpdGhvdXQgdGltZXMgc3BlY2lmaWVkLCB1c2UgY29udGV4dHVhbCBjbHVlcyBhYm91dCB0aGUgZXZlbnQgdHlwZTpcbiAgICAgICogRXZlbmluZyBldmVudHMgKHBhcnRpZXMsIHNob3dzKTogZGVmYXVsdCB0byA3OjAwIFBNXG4gICAgICAqIE1vcm5pbmcgZXZlbnRzIChicnVuY2hlcywgcmFjZXMpOiBkZWZhdWx0IHRvIDk6MDAgQU1cbiAgICAgICogQnVzaW5lc3MgZXZlbnRzOiBkZWZhdWx0IHRvIDEwOjAwIEFNXG4gICAgLSBMb29rIGZvciB0aW1lIHpvbmUgaW5mb3JtYXRpb24sIGRlZmF1bHRpbmcgdG8gbG9jYWwgdGltZSBpZiBub25lIGlzIHNwZWNpZmllZFxuICAgIC0gSGFuZGxlIHJlbGF0aXZlIGRhdGVzIGxpa2UgXCJ0b21vcnJvd1wiLCBcIm5leHQgRnJpZGF5XCIsIGV0Yy5cbiAgICAtIFJlY29nbml6ZSB2YXJpb3VzIHRpbWUgZm9ybWF0cyAoMTItaG91ciwgMjQtaG91ciwgd3JpdHRlbiBvdXQpXG4gICAgXG4gICAgUmV0dXJuIGEgSlNPTiBvYmplY3Qgd2l0aCB0aGVzZSBmaWVsZHM6XG4gICAgLSB0aXRsZTogc3RyaW5nICh0aGUgZXZlbnQgbmFtZSlcbiAgICAtIGRhdGVzOiBzdHJpbmdbXSAoYXJyYXkgb2YgYWxsIG1lbnRpb25lZCBkYXRlcyB3aXRoIHRpbWVzLCBpbiBmb3JtYXRzIGxpa2UgXCJNYXJjaCAxNSwgJHtjdXJyZW50WWVhcn0gNzozMCBQTVwiIG9yIFwiJHtjdXJyZW50WWVhcn0tMDMtMTUgMTk6MzBcIilcbiAgICAtIGxvY2F0aW9uOiB7IG5hbWU6IHN0cmluZywgYWRkcmVzcz86IHN0cmluZyB9XG4gICAgLSBkZXNjcmlwdGlvbjogc3RyaW5nXG4gICAgLSB0eXBlOiBcInNvY2lhbFwiIHwgXCJidXNpbmVzc1wiIHwgXCJlbnRlcnRhaW5tZW50XCJcbiAgICBgO1xuXG4gICAgbGV0IGV4dHJhY3RlZFRleHQgPSAnJztcblxuICAgIC8vIEhhbmRsZSBVUkwgcHJvY2Vzc2luZyB3aXRoIFB1cHBldGVlclxuICAgIGlmICh1cmwpIHtcbiAgICAgIGNvbnNvbGUubG9nKCdQcm9jZXNzaW5nIFVSTDonLCB1cmwpO1xuICAgICAgY29uc3QgYnJvd3NlciA9IGF3YWl0IHB1cHBldGVlci5sYXVuY2goKTtcbiAgICAgIGNvbnN0IHBhZ2UgPSBhd2FpdCBicm93c2VyLm5ld1BhZ2UoKTtcbiAgICAgIGF3YWl0IHBhZ2UuZ290byh1cmwsIHsgd2FpdFVudGlsOiAnbmV0d29ya2lkbGUyJyB9KTtcbiAgICAgIGV4dHJhY3RlZFRleHQgPSBhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+IGRvY3VtZW50LmJvZHkuaW5uZXJUZXh0KTtcbiAgICAgIGF3YWl0IGJyb3dzZXIuY2xvc2UoKTtcbiAgICB9XG5cbiAgICAvLyBIYW5kbGUgSW1hZ2UgcHJvY2Vzc2luZyB3aXRoIEdvb2dsZSBWaXNpb25cbiAgICBpZiAoZmlsZSkge1xuICAgICAgY29uc29sZS5sb2coJ1Byb2Nlc3NpbmcgZmlsZTonLCBmaWxlLm5hbWUpO1xuICAgICAgY29uc3QgYnVmZmVyID0gQnVmZmVyLmZyb20oYXdhaXQgZmlsZS5hcnJheUJ1ZmZlcigpKTtcbiAgICAgIGNvbnN0IFtyZXN1bHRdID0gYXdhaXQgY2xpZW50LnRleHREZXRlY3Rpb24oYnVmZmVyKTtcbiAgICAgIGNvbnN0IGRldGVjdGlvbnMgPSByZXN1bHQudGV4dEFubm90YXRpb25zO1xuICAgICAgZXh0cmFjdGVkVGV4dCA9IGRldGVjdGlvbnMgPyBkZXRlY3Rpb25zWzBdLmRlc2NyaXB0aW9uIDogJyc7XG4gICAgfVxuXG4gICAgaWYgKCFleHRyYWN0ZWRUZXh0KSB7XG4gICAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oeyBlcnJvcjogJ05vIHRleHQgY291bGQgYmUgZXh0cmFjdGVkJyB9LCB7IHN0YXR1czogNDAwIH0pO1xuICAgIH1cblxuICAgIGNvbnNvbGUubG9nKCdFeHRyYWN0ZWQgdGV4dDonLCBleHRyYWN0ZWRUZXh0KTtcblxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgb3BlbmFpLmNoYXQuY29tcGxldGlvbnMuY3JlYXRlKHtcbiAgICAgIG1vZGVsOiBcImdwdC0zLjUtdHVyYm9cIixcbiAgICAgIG1lc3NhZ2VzOiBbXG4gICAgICAgIHtcbiAgICAgICAgICByb2xlOiBcInN5c3RlbVwiLFxuICAgICAgICAgIGNvbnRlbnQ6IHN5c3RlbVByb21wdCxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIHJvbGU6IFwidXNlclwiLFxuICAgICAgICAgIGNvbnRlbnQ6IGBFeHRyYWN0IGV2ZW50IGluZm9ybWF0aW9uIGZyb20gdGhpcyB0ZXh0OlxcblxcbiR7ZXh0cmFjdGVkVGV4dH1gLFxuICAgICAgICB9LFxuICAgICAgXSxcbiAgICAgIG1heF90b2tlbnM6IDUwMCxcbiAgICB9KTtcblxuICAgIGNvbnN0IGdwdENvbnRlbnQgPSByZXNwb25zZS5jaG9pY2VzWzBdPy5tZXNzYWdlPy5jb250ZW50O1xuICAgIGNvbnN0IHJhd0V2ZW50RGF0YSA9IEpTT04ucGFyc2UoZ3B0Q29udGVudCB8fCAne30nKTtcblxuICAgIC8vIFByb2Nlc3MgYW5kIGZvcm1hdCB0aGUgZGF0ZXNcbiAgICBjb25zdCBwcm9jZXNzZWRFdmVudERhdGEgPSB7XG4gICAgICAuLi5yYXdFdmVudERhdGEsXG4gICAgICBkYXRldGltZTogcmF3RXZlbnREYXRhLmRhdGVzICYmIHJhd0V2ZW50RGF0YS5kYXRlcy5sZW5ndGggPiAwIFxuICAgICAgICA/IHBhcnNlRGF0ZVRpbWVTdHJpbmcocmF3RXZlbnREYXRhLmRhdGVzWzBdKVxuICAgICAgICA6IG51bGwsXG4gICAgICAvLyBLZWVwIHRoZSBvcmlnaW5hbCBkYXRlcyBhcnJheSBmb3IgcmVmZXJlbmNlXG4gICAgICBhbGxEYXRlczogcmF3RXZlbnREYXRhLmRhdGVzPy5tYXAoKGRhdGU6IHN0cmluZykgPT4gKHtcbiAgICAgICAgb3JpZ2luYWw6IGRhdGUsXG4gICAgICAgIHBhcnNlZDogcGFyc2VEYXRlVGltZVN0cmluZyhkYXRlKVxuICAgICAgfSkpXG4gICAgfTtcblxuICAgIGNvbnNvbGUubG9nKCdQcm9jZXNzZWQgZXZlbnQgZGF0YTonLCBwcm9jZXNzZWRFdmVudERhdGEpO1xuXG4gICAgaWYgKCFwcm9jZXNzZWRFdmVudERhdGEuZGF0ZXRpbWUpIHtcbiAgICAgIGNvbnNvbGUud2FybignQ291bGQgbm90IHBhcnNlIGFueSB2YWxpZCBkYXRlcyBmcm9tOicsIHJhd0V2ZW50RGF0YS5kYXRlcyk7XG4gICAgfVxuXG4gICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHByb2Nlc3NlZEV2ZW50RGF0YSk7XG5cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKCdQcm9jZXNzaW5nIGVycm9yOicsIGVycm9yKTtcbiAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oeyBlcnJvcjogJ0ZhaWxlZCB0byBwcm9jZXNzIHJlcXVlc3QnIH0sIHsgc3RhdHVzOiA1MDAgfSk7XG4gIH1cbn0iXSwibmFtZXMiOlsiTmV4dFJlc3BvbnNlIiwidmlzaW9uIiwiT3BlbkFJIiwicHVwcGV0ZWVyIiwicHJvY2VzcyIsImVudiIsIkdPT0dMRV9DTE9VRF9QUk9KRUNUX0lEIiwiRXJyb3IiLCJHT09HTEVfQ0xPVURfUFJJVkFURV9LRVkiLCJHT09HTEVfQ0xPVURfQ0xJRU5UX0VNQUlMIiwiT1BFTkFJX0FQSV9LRVkiLCJjbGllbnQiLCJJbWFnZUFubm90YXRvckNsaWVudCIsImNyZWRlbnRpYWxzIiwicHJvamVjdF9pZCIsInByaXZhdGVfa2V5IiwicmVwbGFjZSIsImNsaWVudF9lbWFpbCIsIm9wZW5haSIsImFwaUtleSIsInBhcnNlRGF0ZVRpbWVTdHJpbmciLCJkYXRlVGltZVN0cmluZyIsImN1cnJlbnRZZWFyIiwiRGF0ZSIsImdldEZ1bGxZZWFyIiwic2hvcnREYXRlUmVnZXgiLCJtYXRjaCIsIl8iLCJtb250aCIsImRheSIsInllYXJQYXJ0IiwieWVhciIsInBhcnNlSW50IiwicHJvcG9zZWREYXRlIiwiZGVmYXVsdEhvdXIiLCJkZWZhdWx0TWludXRlIiwidGltZU1hdGNoIiwiaG91cnMiLCJtaW51dGVzIiwibWVyaWRpZW0iLCJob3VyIiwidG9Mb3dlckNhc2UiLCJmaW5hbERhdGUiLCJ0b0lTT1N0cmluZyIsImRhdGUiLCJpc05hTiIsImdldFRpbWUiLCJzZXRGdWxsWWVhciIsImVycm9yIiwiY29uc29sZSIsIlBPU1QiLCJyZXEiLCJsb2ciLCJmb3JtRGF0YSIsInVybCIsImdldCIsImZpbGUiLCJzeXN0ZW1Qcm9tcHQiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJleHRyYWN0ZWRUZXh0IiwiYnJvd3NlciIsImxhdW5jaCIsInBhZ2UiLCJuZXdQYWdlIiwiZ290byIsIndhaXRVbnRpbCIsImV2YWx1YXRlIiwiZG9jdW1lbnQiLCJib2R5IiwiaW5uZXJUZXh0IiwiY2xvc2UiLCJuYW1lIiwiYnVmZmVyIiwiQnVmZmVyIiwiZnJvbSIsImFycmF5QnVmZmVyIiwicmVzdWx0IiwidGV4dERldGVjdGlvbiIsImRldGVjdGlvbnMiLCJ0ZXh0QW5ub3RhdGlvbnMiLCJkZXNjcmlwdGlvbiIsImpzb24iLCJzdGF0dXMiLCJyZXNwb25zZSIsImNoYXQiLCJjb21wbGV0aW9ucyIsImNyZWF0ZSIsIm1vZGVsIiwibWVzc2FnZXMiLCJyb2xlIiwiY29udGVudCIsIm1heF90b2tlbnMiLCJncHRDb250ZW50IiwiY2hvaWNlcyIsIm1lc3NhZ2UiLCJyYXdFdmVudERhdGEiLCJKU09OIiwicGFyc2UiLCJwcm9jZXNzZWRFdmVudERhdGEiLCJkYXRldGltZSIsImRhdGVzIiwibGVuZ3RoIiwiYWxsRGF0ZXMiLCJtYXAiLCJvcmlnaW5hbCIsInBhcnNlZCIsIndhcm4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./app/api/process/route.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/formdata-node","vendor-chunks/@grpc","vendor-chunks/openai","vendor-chunks/google-gax","vendor-chunks/protobufjs","vendor-chunks/google-auth-library","vendor-chunks/@google-cloud","vendor-chunks/uuid","vendor-chunks/readable-stream","vendor-chunks/proto3-json-serializer","vendor-chunks/form-data-encoder","vendor-chunks/@protobufjs","vendor-chunks/gaxios","vendor-chunks/whatwg-url","vendor-chunks/jws","vendor-chunks/debug","vendor-chunks/agentkeepalive","vendor-chunks/json-bigint","vendor-chunks/tr46","vendor-chunks/inherits","vendor-chunks/https-proxy-agent","vendor-chunks/gcp-metadata","vendor-chunks/ecdsa-sig-formatter","vendor-chunks/agent-base","vendor-chunks/long","vendor-chunks/wrappy","vendor-chunks/webidl-conversions","vendor-chunks/util-deprecate","vendor-chunks/supports-color","vendor-chunks/string_decoder","vendor-chunks/stream-shift","vendor-chunks/safe-buffer","vendor-chunks/retry-request","vendor-chunks/once","vendor-chunks/object-hash","vendor-chunks/ms","vendor-chunks/lodash.camelcase","vendor-chunks/jwa","vendor-chunks/is","vendor-chunks/humanize-ms","vendor-chunks/has-flag","vendor-chunks/gtoken","vendor-chunks/extend","vendor-chunks/event-target-shim","vendor-chunks/end-of-stream","vendor-chunks/duplexify","vendor-chunks/buffer-equal-constant-time","vendor-chunks/bignumber.js","vendor-chunks/base64-js","vendor-chunks/abort-controller","vendor-chunks/@js-sdsl"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Fprocess%2Froute&page=%2Fapi%2Fprocess%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fprocess%2Froute.ts&appDir=%2FUsers%2Fmichael%2FDocuments%2FTapdIn%2Fcreate3%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2FUsers%2Fmichael%2FDocuments%2FTapdIn%2Fcreate3&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();