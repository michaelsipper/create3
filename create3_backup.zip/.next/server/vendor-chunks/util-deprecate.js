/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "vendor-chunks/util-deprecate";
exports.ids = ["vendor-chunks/util-deprecate"];
exports.modules = {

/***/ "(rsc)/./node_modules/util-deprecate/node.js":
/*!*********************************************!*\
  !*** ./node_modules/util-deprecate/node.js ***!
  \*********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("\n/**\n * For Node.js, simply re-export the core `util.deprecate` function.\n */\n\nmodule.exports = __webpack_require__(/*! util */ \"util\").deprecate;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvdXRpbC1kZXByZWNhdGUvbm9kZS5qcyIsIm1hcHBpbmdzIjoiO0FBQ0E7QUFDQTtBQUNBOztBQUVBLGtFQUEwQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NyZWF0ZTMvLi9ub2RlX21vZHVsZXMvdXRpbC1kZXByZWNhdGUvbm9kZS5qcz83ZWU0Il0sInNvdXJjZXNDb250ZW50IjpbIlxuLyoqXG4gKiBGb3IgTm9kZS5qcywgc2ltcGx5IHJlLWV4cG9ydCB0aGUgY29yZSBgdXRpbC5kZXByZWNhdGVgIGZ1bmN0aW9uLlxuICovXG5cbm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgndXRpbCcpLmRlcHJlY2F0ZTtcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/util-deprecate/node.js\n");

/***/ })

};
;