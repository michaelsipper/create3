import CreatePlanType3 from "@/components/create/type3/CreatePlanType3";

export default function Home() {
  return (
    <main>
      <CreatePlanType3 />
    </main>
  );
}